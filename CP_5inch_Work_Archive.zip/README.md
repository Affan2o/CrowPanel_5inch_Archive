# CrowPanel 5-inch ESP32 Work

This repository contains archived work done for the 5-inch CrowPanel using ESP32 and LVGL.
